from chalice import Chalice, BadRequestError
# from jinja2 import Template

app = Chalice(app_name='chalice-helloworld')

app.debug = True

@app.route('/')
def index():
    try:
        return {"value": "TEST"}
    except KeyError:
        raise BadRequestError("Unknown city")
